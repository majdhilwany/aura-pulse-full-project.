// AURA PULSE - Interactive Engine

document.addEventListener('DOMContentLoaded', () => {
  initParticleCanvas();
  initAudioVisualizer();
  initCounters();
  initAccordion();
});

// 1. Particle Background Animation
function initParticleCanvas() {
  const canvas = document.getElementById('bgCanvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  let particles = [];

  function resizeCanvas() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
  }
  
  window.addEventListener('resize', resizeCanvas);
  resizeCanvas();

  class Particle {
    constructor() {
      this.reset();
    }
    reset() {
      this.x = Math.random() * canvas.width;
      this.y = Math.random() * canvas.height;
      this.size = Math.random() * 2 + 0.5;
      this.speedX = (Math.random() - 0.5) * 0.4;
      this.speedY = (Math.random() - 0.5) * 0.4;
      this.alpha = Math.random() * 0.5 + 0.15;
    }
    update() {
      this.x += this.speedX;
      this.y += this.speedY;
      if (this.x < 0 || this.x > canvas.width || this.y < 0 || this.y > canvas.height) {
        this.reset();
      }
    }
    draw() {
      ctx.fillStyle = `rgba(6, 182, 212, ${this.alpha})`;
      ctx.beginPath();
      ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  for (let i = 0; i < 85; i++) {
    particles.push(new Particle());
  }

  function render() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    particles.forEach(p => {
      p.update();
      p.draw();
    });
    requestAnimationFrame(render);
  }
  render();
}

// 2. Audio Spectrum Visualizer Simulation
function initAudioVisualizer() {
  const container = document.getElementById('visualizer');
  if (!container) return;
  const barCount = 42;
  const bars = [];

  for (let i = 0; i < barCount; i++) {
    const bar = document.createElement('div');
    bar.className = 'bar';
    container.appendChild(bar);
    bars.push(bar);
  }

  function animateBars() {
    bars.forEach((bar) => {
      const height = Math.floor(Math.random() * 85) + 15;
      bar.style.height = `${height}%`;
    });
    setTimeout(animateBars, 110);
  }
  animateBars();
}

// 3. Animated Number Counters
function initCounters() {
  const counters = document.querySelectorAll('.counter');
  let started = false;

  const startCounting = () => {
    counters.forEach((counter) => {
      const target = +counter.getAttribute('data-target');
      let count = 0;
      const step = target / 60;

      const update = () => {
        count += step;
        if (count < target) {
          counter.innerText = count.toFixed(target % 1 !== 0 ? 1 : 0);
          requestAnimationFrame(update);
        } else {
          counter.innerText = target;
        }
      };
      update();
    });
  };

  window.addEventListener('scroll', () => {
    const section = document.querySelector('.stats');
    if (section && !started) {
      const rect = section.getBoundingClientRect();
      if (rect.top <= window.innerHeight * 0.8) {
        started = true;
        startCounting();
      }
    }
  });
}

// 4. FAQ Accordion Toggle
function initAccordion() {
  const questions = document.querySelectorAll('.faq-question');
  questions.forEach((q) => {
    q.addEventListener('click', () => {
      const parent = q.parentElement;
      const isActive = parent.classList.contains('active');
      
      document.querySelectorAll('.faq-item').forEach((item) => {
        item.classList.remove('active');
      });

      if (!isActive) {
        parent.classList.add('active');
      }
    });
  });
}
