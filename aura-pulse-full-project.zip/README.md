# AURA PULSE — Next-Gen Landing Page

An ultra-modern, glassmorphic landing page designed for maximum performance, full responsiveness, and smooth visual animations.

## Structure

```
aura-pulse-landing/
│
├── index.html          # Main HTML5 Layout
├── css/
│   └── style.css       # Complete Glassmorphism & Adaptive Layout
├── js/
│   └── main.js         # Canvas Particles, Visualizer & Interactivity
└── README.md
```

## How to Deploy

### Option 1: GitHub & Vercel (Recommended)
1. Unzip this directory.
2. Create a new repository on GitHub and upload all files keeping the folder structure intact.
3. Go to [Vercel](https://vercel.com) -> Import Project -> Select your GitHub repository.
4. Click **Deploy** (No special build command needed).

### Option 2: GitHub Pages
1. Go to your Repository Settings on GitHub.
2. Navigate to **Pages** -> Source: `main` branch -> `/root`.
3. Save and your live site link will be active!
